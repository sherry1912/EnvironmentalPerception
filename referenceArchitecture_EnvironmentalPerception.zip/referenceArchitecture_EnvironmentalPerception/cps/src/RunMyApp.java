import com.alibaba.fastjson.JSONObject;

import pku.facilitator.FacilitatorImpl;
import pku.facilitator.FacilitatorInterface;
import pku.facilitator.FacilitatorTier;
import pku.pretreatment.PretreatmentImpl;
import pku.pretreatment.PretreatmentInterface;
import pku.pretreatment.PretreatmentTier;
import pku.transport.TransportImpl;
import pku.transport.TransportInterface;
import pku.transport.TransportTier;
import pku.validation.ValidationImpl;
import pku.validation.ValidationInterface;
import pku.validation.ValidationTier;

public class RunMyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
			FacilitatorInterface FacilitatorInterface_1 = new FacilitatorImpl();
			ValidationInterface ValidationInterface_1 = new ValidationImpl();
			JSONObject validatedJson = ValidationInterface_1.validate(FacilitatorInterface_1.sensingRawValue());
		
			if(validatedJson.getBoolean("success")) {
				PretreatmentInterface PretreatmentInterface_1 = new PretreatmentImpl();
				if(PretreatmentInterface_1.predict(PretreatmentInterface_1.aggregate(validatedJson))) {
					TransportInterface TransportInterface_1 = new TransportImpl();
					TransportInterface_1.Transfer();
					//TransportTier.tranferSmartRoom();
					//TransportTier.tranferMedical();
				}
			}else
				return;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
