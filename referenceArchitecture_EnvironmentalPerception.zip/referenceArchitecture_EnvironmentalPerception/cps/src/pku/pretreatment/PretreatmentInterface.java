package pku.pretreatment;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public interface PretreatmentInterface {
	public JSONArray aggregate(JSONObject validatedJson) throws Exception;
	public boolean predict (JSONArray temperatureHistoryDataArray) throws Exception;
}
