package pku.pretreatment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import pku.util.CommonFun;

public class PretreatmentTier {
	
	public static JSONArray aggregateData(JSONObject validatedJson) throws Exception{
		/**�������ʪ��***/
		String humidityHistoryData = CommonFun.readStoreData("src/pku/database/data_history/Data_relative_humidity.txt");
		JSONArray humidityHistoryDataArray = JSONArray.parseArray(humidityHistoryData);
		JSONObject tempO = new JSONObject();
		tempO.put("Data_relative_humidity", "16%");
		humidityHistoryDataArray.add(tempO);
		//д����ʷ����
		CommonFun.writeToHistoryData("src/pku/database/data_history/Data_relative_humidity.txt",humidityHistoryDataArray.toString());
		//���µ�ǰ����
		CommonFun.writeToHistoryData("src/pku/database/data_current/Data_relative_humidity.txt",tempO.toString());
		
		/**�û��¶�***/
		String temperatureHistoryData = CommonFun.readStoreData("src/pku/database/data_history/Data_user_temperature.txt");
		JSONArray temperatureHistoryDataArray = JSONArray.parseArray(temperatureHistoryData);
		JSONObject tempOO = new JSONObject();
		tempOO.put("Data_user_temperature", validatedJson.get("Sentemperature"));
		temperatureHistoryDataArray.add(tempOO);
		//д����ʷ����
		CommonFun.writeToHistoryData("src/pku/database/data_history/Data_user_temperature.txt",temperatureHistoryDataArray.toString());
		//���µ�ǰ����
		CommonFun.writeToHistoryData("src/pku/database/data_current/Data_user_temperature.txt",tempOO.toString());
		

		return temperatureHistoryDataArray;
	}
	
	public static boolean predictData(JSONArray temperatureHistoryDataArray) throws Exception{
		//Ԥ������
				double sumUserTemperature = 0;
				System.out.println("temperatureHistoryDataArray---"+temperatureHistoryDataArray.toString());
				for(int i= 0; i < temperatureHistoryDataArray.size(); i++){
					JSONObject tempOOO = JSONObject.parseObject(temperatureHistoryDataArray.getString(i));
					sumUserTemperature += tempOOO.getDouble("Data_user_temperature");
				}
				//д���¶ȵ�Ԥ������
				JSONObject tempOOOO = new JSONObject();
				tempOOOO.put("Data_user_temperature", sumUserTemperature/temperatureHistoryDataArray.size());
				System.out.println(tempOOOO.toString());
				CommonFun.writeToHistoryData("src/pku/database/data_prediction/Data_user_temperature.txt",tempOOOO.toString());
		return true;
	}

}
