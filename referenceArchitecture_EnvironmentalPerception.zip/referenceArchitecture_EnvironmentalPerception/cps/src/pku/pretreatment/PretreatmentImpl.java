package pku.pretreatment;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import pku.transport.TransportTier;

public class PretreatmentImpl implements PretreatmentInterface{
	public JSONArray aggregate(JSONObject validatedJson) throws Exception{
		return PretreatmentTier.aggregateData(validatedJson);
	}
	
	public boolean predict(JSONArray temperatureHistoryDataArray) throws Exception{
		return PretreatmentTier.predictData(temperatureHistoryDataArray);
	}
}
