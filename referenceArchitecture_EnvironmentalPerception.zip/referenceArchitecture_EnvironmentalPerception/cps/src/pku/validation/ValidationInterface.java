package pku.validation;

import com.alibaba.fastjson.JSONObject;

public interface ValidationInterface {
	JSONObject validate(String roughData) throws Exception;

}
