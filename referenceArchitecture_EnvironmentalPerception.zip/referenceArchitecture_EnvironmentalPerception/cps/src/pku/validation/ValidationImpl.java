package pku.validation;

import com.alibaba.fastjson.JSONObject;

import pku.facilitator.FacilitatorTier;

public class ValidationImpl implements ValidationInterface{

	@Override
	public JSONObject validate(String roughData) throws Exception {
		// TODO Auto-generated method stub
		return ValidationTier.validateData(roughData);
	}

}
