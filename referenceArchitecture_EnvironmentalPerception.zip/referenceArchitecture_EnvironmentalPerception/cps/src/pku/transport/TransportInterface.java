package pku.transport;

public interface TransportInterface {

	boolean Transfer() throws Exception;
}
