package pku.transport;

public class TransportImpl implements TransportInterface {

	public boolean Transfer() throws Exception{
		TransportTier.tranferSmartRoom();
		TransportTier.tranferMedical();
		return true;
	}
}
