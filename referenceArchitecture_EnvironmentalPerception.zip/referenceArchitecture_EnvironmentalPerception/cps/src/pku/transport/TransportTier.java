package pku.transport;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import pku.util.CommonFun;

public class TransportTier {
	
	public static final String[] SMART_ROOM_SYSTEM_CONFIG = {"Data_temperature","Data_air_conditioner","Data_relative_humidity","Data_humidifer","Data_user_location"};
	
	public static final String[] INTELLIGENT_MEDICAL_SYSYTEM_CONFIG = {"Data_heart_rate","Data_user_temperature","Data_user_location"};

	public static String tranferSmartRoom() throws Exception{
		String[] smartRoomConfig = TransportTier.SMART_ROOM_SYSTEM_CONFIG;
		for(int i = 0; i < smartRoomConfig.length; i++) {
			//���������ļ�
			//��ȡ��ʷ����
			String historyData = CommonFun.readStoreData("src/pku/database/data_history/"+smartRoomConfig[i]+".txt");
			JSONArray historyDataArray = JSONArray.parseArray(historyData);
			//��ȡԤ������
			historyData = CommonFun.readStoreData("src/pku/database/data_prefiction/"+smartRoomConfig[i]+".txt");
			JSONObject temp = JSONObject.parseObject(historyData);
			historyDataArray.add(temp);
			System.out.println("SmartRoomSystem Data---"+historyDataArray.toString());
			//д��Ӧ�ò㱣��
			CommonFun.writeToHistoryData("src/pku/applications/SmartRoomSystem/context/"+smartRoomConfig[i]+".txt", historyDataArray.toString());
		}
		return "";
	}
	
	public static String tranferMedical() throws Exception{
		String[] medicalConfig = TransportTier.INTELLIGENT_MEDICAL_SYSYTEM_CONFIG;
		for(int i = 0; i < medicalConfig.length; i++) {
			//���������ļ�
			//��ȡ��ʷ����
			String historyData = CommonFun.readStoreData("src/pku/database/data_history/"+medicalConfig[i]+".txt");
			JSONArray historyDataArray = JSONArray.parseArray(historyData);
			//��ȡԤ������
			historyData = CommonFun.readStoreData("src/pku/database/data_prefiction/"+medicalConfig[i]+".txt");
			JSONObject temp = JSONObject.parseObject(historyData);
			historyDataArray.add(temp);
			System.out.println("IntelligentMedicalSystem Data---"+historyDataArray.toString());
			//д��Ӧ�ò㱣��
			CommonFun.writeToHistoryData("src/pku/applications/IntelligentMedicalSystem/context/"+medicalConfig[i]+".txt", historyDataArray.toString());
		}
		return "";
	}
	
}
