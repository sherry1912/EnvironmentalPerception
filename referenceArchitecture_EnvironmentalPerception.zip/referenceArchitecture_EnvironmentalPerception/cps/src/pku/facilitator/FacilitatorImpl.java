package pku.facilitator;

public class FacilitatorImpl implements FacilitatorInterface{

	@Override
	public String sensingRawValue() throws Exception {
		// TODO Auto-generated method stub
		return FacilitatorTier.readData();
	}

}
