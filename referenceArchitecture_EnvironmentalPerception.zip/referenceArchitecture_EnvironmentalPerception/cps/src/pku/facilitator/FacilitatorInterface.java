package pku.facilitator;

public interface FacilitatorInterface {
	String sensingRawValue() throws Exception;
}
