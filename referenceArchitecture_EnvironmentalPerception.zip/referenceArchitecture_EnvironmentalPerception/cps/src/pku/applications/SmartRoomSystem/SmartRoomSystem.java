package pku.applications.SmartRoomSystem;

import com.alibaba.fastjson.JSONArray;

import pku.applications.ApplicationInterface;
import pku.transport.TransportTier;
import pku.util.CommonFun;

public class SmartRoomSystem implements ApplicationInterface{
	

	@Override
	public void identify() throws Exception {
		// TODO Auto-generated method stub
		// identify "comfort_low" and saves the situation in the knowledge
	}

}
