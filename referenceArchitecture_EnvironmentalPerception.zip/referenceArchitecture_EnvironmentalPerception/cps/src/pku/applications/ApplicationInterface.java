package pku.applications;

public interface ApplicationInterface {
	void identify() throws Exception;
}
