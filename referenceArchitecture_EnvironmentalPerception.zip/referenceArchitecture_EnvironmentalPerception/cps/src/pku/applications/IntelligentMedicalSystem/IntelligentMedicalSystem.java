package pku.applications.IntelligentMedicalSystem;

import pku.applications.ApplicationInterface;

public class IntelligentMedicalSystem implements ApplicationInterface{
	

	@Override
	public void identify() throws Exception {
		// TODO Auto-generated method stub
		// identify "sleep" and save it in the knowledge base
	}
}
